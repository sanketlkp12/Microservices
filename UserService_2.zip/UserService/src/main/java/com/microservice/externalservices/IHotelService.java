package com.microservice.externalservices;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.microservice.entity.Hotel;


@FeignClient(name="HotelService")
public interface IHotelService {

	@GetMapping("hotels/{hotelId}")
	Hotel getHotel(@PathVariable("hotelId") String hotelId);
}
