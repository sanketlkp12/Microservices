package com.hotelservice.service;

import java.util.List;

import com.hotelservice.entity.Hotel;

public interface HotelService {

	//create
	Hotel create(Hotel hotel);
	
	//get all
	List<Hotel> getAllHotels();
	
	//get single hotel
	Hotel getSingleHotel(String id);
}
