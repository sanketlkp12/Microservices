const mongoose = require('mongoose');

const ratingschema = new mongoose.Schema({
    userId:{type:String,require:true},
    hotelId:{type:String, require:true},
    rating:{type:Number, require: true},
    feedback:{type:String}
}, {
    collection: 'user_ratings' // Explicitly specify the collection name
  });
  
module.exports = mongoose.model('Rating', ratingschema);