const Eureka = require('eureka-js-client').Eureka;

const eureka = new Eureka({
  instance: {
    app: 'Node-RATING-SERVICE',
    hostName: 'localhost',
    ipAddr: '127.0.0.1',
    port: {
      '$': 8082,
      '@enabled': true
    },
    vipAddress: 'rating-service',
    secureVipAddress: 'rating-service',
    dataCenterInfo: {
      '@class': 'com.netflix.appinfo.InstanceInfo$DefaultDataCenterInfo',
      name: 'MyOwn'
    }
  },
  eureka: {
    host: 'localhost',
    port: 8761,
    servicePath: '/eureka/apps/'
  }
});

module.exports = eureka;
