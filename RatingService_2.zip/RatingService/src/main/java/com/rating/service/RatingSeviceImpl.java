package com.rating.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.rating.entity.Ratings;
import com.rating.repo.RatingRepository;

@Service
@Transactional
public class RatingSeviceImpl implements IRatingService {

	@Autowired
	private RatingRepository ratingRepository;
	
	@Override
	public Ratings create(Ratings rating) {
		// TODO Auto-generated method stub
		return ratingRepository.save(rating);
	}
	
	public Ratings update(String ratingId,Ratings rating) {
		// TODO Auto-generated method stub
	//	Ratings updatedRatings = ratingRepository.findById(ratingId);
		Ratings existingRating = ratingRepository.findById(ratingId).orElseThrow();
		// Update fields with new values
        existingRating.setRating(rating.getRating());
        existingRating.setFeedback(rating.getFeedback());

		return ratingRepository.save(existingRating);
	}

	@Override
	public List<Ratings> getRatings() {
		// TODO Auto-generated method stub
		return ratingRepository.findAll();
	}

	@Override
	public List<Ratings> getRatingByUserid(String userId) {
		// TODO Auto-generated method stub
		return ratingRepository.findByUserId(userId);
	}

	@Override
	public List<Ratings> getRatingByHotelId(String hotelId) {
		// TODO Auto-generated method stub
		return ratingRepository.findByHotelId(hotelId);
	}

}
