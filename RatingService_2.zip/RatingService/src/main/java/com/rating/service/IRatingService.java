package com.rating.service;

import java.util.List;

import com.rating.entity.Ratings;

public interface IRatingService {

	//create
	Ratings create(Ratings rating);
	
	//get all ratings
	List<Ratings> getRatings();
	
	//get all by userid
	List<Ratings> getRatingByUserid(String userId);
	
	//get all by hotel
	List<Ratings> getRatingByHotelId(String hotelId);
	
}
