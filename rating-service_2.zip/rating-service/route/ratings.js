const express = require('express');
const router = express.Router();
const ratingService = require('../services/ratingservice');

// Get all ratings
router.get('/', async (req, res) => {
  try {
    const ratings = await ratingService.getAllRatings();
    res.json(ratings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Find rating by userId
router.get('/users/:userId', async (req, res) => {
  try {
    const userId = req.params.userId;
    const ratings = await ratingService.getRatingsByUserId(userId);
    res.json(ratings);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Create a new rating
router.post('/', async (req, res) => {
  try {
    const newRating = await ratingService.createRating(req.body);
    res.status(201).json(newRating);
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
});

module.exports = router;
