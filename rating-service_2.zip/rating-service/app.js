const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const ratingRoutes = require('./route/ratings');
const eureka = require('./config/eureka');

const app = express();

// Middleware
app.use(bodyParser.json());
app.use('/ratings', ratingRoutes);

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/ratingservice', {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
  .then(() => console.log('Connected to MongoDB'))
  .catch(err => console.error('MongoDB connection error:', err));

// Start Eureka client
eureka.start(() => {
  console.log('Eureka client started');
});

// Start server
const PORT = process.env.PORT || 8082;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
