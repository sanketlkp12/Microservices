package com.microservice.externalservices;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.microservice.entity.Rating;

@Service
@FeignClient(name="RATINGSERVICE")
public interface IRatingService {

	@GetMapping("/ratings")
	Rating getRating();
	
	@GetMapping("/ratings/{ratingId}")
	Rating getRatingById(@PathVariable("ratingId") String ratingId);
	
	@GetMapping("/ratings/{hotelId}")
	Rating getRatingByHotelId(@PathVariable("hotelId") String hotelId);
	
	@PostMapping("/ratings")
	Rating createRating(@RequestBody Rating rating);
	
	@PutMapping("/ratings/{ratingId}")
	Rating updateRating(@PathVariable("ratingId") String ratingId,@RequestBody Rating values); 
	
	@DeleteMapping("/ratings/{ratingId}")
	void deleteRating(@PathVariable String ratingId);
}
