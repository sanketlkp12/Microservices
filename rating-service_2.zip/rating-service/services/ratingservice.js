const Rating = require('../model/Rating');

// Get all ratings
const getAllRatings = async () => {
  try {
    return await Rating.find();
  } catch (error) {
    throw new Error(error.message);
  }
};

// Find rating by userId
const getRatingsByUserId = async (userId) => {
  try {
    return await Rating.find({ userId });
  } catch (error) {
    throw new Error(error.message);
  }
};

// Create a new rating
const createRating = async (ratingData) => {
  const rating = new Rating({
    userId: ratingData.userId,
    hotelId: ratingData.hotelId,
    rating: ratingData.rating,
    feedback: ratingData.feedback
  });

  try {
    return await rating.save();
  } catch (error) {
    throw new Error(error.message);
  }
};

//Update rating by ratingId
const updateRating = async (ratingData, ratingId)=>{
    const updatedData = await Rating.findByIdAndUpdate(ratingId,ratingData);
    return updatedData;
}

module.exports = {
  getAllRatings,
  getRatingsByUserId,
  createRating
};
