package com.microservice.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.microservice.entity.Hotel;
import com.microservice.entity.Rating;
import com.microservice.entity.User;
import com.microservice.exception.ResourceNotFoundException;
import com.microservice.externalservices.IHotelService;
import com.microservice.repo.UserRepository;


import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private IHotelService hotelService;
	
	//Using RestTemplate to be used as client to call another service
	@Autowired
	private RestTemplate restTemplate;

	private Logger logger = LoggerFactory.getLogger(UserService.class);
	
	public User saveUser(User user) {
        return userRepository.save(user);
    }

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(String userId) {
    	//Get user from database with the help of user repository
        User user = userRepository.findById(userId).orElseThrow(()->new ResourceNotFoundException("Usere with given id is not fouund on server!!"+userId));
        //fetch rating of above user from RatingService
        //http://localhost:8082/ratings/users/57c54f28-4573-4a0f-8780-8e09db649bc6
      Rating[] ratingsOfUser =  restTemplate.getForObject("http://RATINGSERVICE/ratings/users/"+user.getUserId(), Rating[].class);
      logger.info("{}",ratingsOfUser);
 
      List<Rating> ratings =Arrays.stream(ratingsOfUser).toList();
      
      List<Rating> ratingList = ratings.stream().map(rating->{
    	  //api call to hotel service to get the hotel
    	  //http://localhost:8081/hotels/c6b4a7d5-19d5-44c3-bf6f-31e246797fea
    //      ResponseEntity<Hotel> forEntity =restTemplate.getForEntity("http://HotelService/hotels/"+rating.getHotelId(), Hotel.class);
      //    Hotel hotel = forEntity.getBody();
       //   logger.info("Response status code: {} ",forEntity.getStatusCode());
    	  Hotel hotel = hotelService.getHotel(rating.getHotelId());
    	  //set the hotel to rating
          rating.setHotel(hotel);
    	  //return the rating
    	  return rating;
      }).collect(Collectors.toList());
      
      user.setRatings(ratingList);
      
        return user;
    }

    public void deleteUser(String userId) {
        userRepository.deleteById(userId);
    }
}

